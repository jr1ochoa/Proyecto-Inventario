
<div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div id='loadModal' class="modal-body">
            
      </div>
      <div class="modal-footer"> 
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
        <button id="btnAction" type="button" class="btn btn-primary" onclick="$('#form').submit()" >Guardar</button>
      </div>
    </div>
  </div>